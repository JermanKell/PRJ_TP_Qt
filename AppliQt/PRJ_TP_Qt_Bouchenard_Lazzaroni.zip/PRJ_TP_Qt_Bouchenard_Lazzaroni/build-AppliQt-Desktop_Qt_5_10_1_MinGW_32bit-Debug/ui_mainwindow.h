/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionQuitter;
    QAction *actionClient;
    QAction *actionPersonnel;
    QAction *actionA_propos;
    QAction *action_client_Tool;
    QAction *action_Personnel_Tool;
    QAction *actionDivers;
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout_Central;
    QTabWidget *tabWidget;
    QWidget *tab_Client;
    QVBoxLayout *verticalLayout_8;
    QVBoxLayout *verticalLayout;
    QVBoxLayout *verticalLayout_TableView;
    QTableView *tableViewClient;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_Recherche;
    QLabel *label_Recherche;
    QFormLayout *formLayout_Recherche;
    QLabel *label_IdRecherche;
    QLineEdit *lineEdit_IdRecherche;
    QLabel *lab_NomRecherche;
    QLineEdit *lineEdit_NomRecherche;
    QLabel *lab_PrenomRecherche;
    QLineEdit *lineEdit_PrenomRecherche;
    QLabel *lab_DateMiniRecherche;
    QDateEdit *dateEditMini;
    QLabel *lab_DateMaxRecherche;
    QDateEdit *dateEditMax;
    QVBoxLayout *verticalLayout_AjoutModif;
    QPushButton *btn_ModifierClient;
    QPushButton *btn_SupprimerClient;
    QWidget *tab_Personnel;
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout_3;
    QTreeView *PersView;
    QPushButton *button_xml;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *PersModif;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *PersSup;
    QWidget *tab_planification;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *button_Plan;
    QVBoxLayout *verticalLayout_5;
    QLabel *label;
    QDateEdit *edit_date;
    QMenuBar *menuBar;
    QMenu *menuFichier;
    QMenu *menuAjouter;
    QMenu *menu;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(655, 510);
        actionQuitter = new QAction(MainWindow);
        actionQuitter->setObjectName(QStringLiteral("actionQuitter"));
        actionQuitter->setCheckable(false);
        actionClient = new QAction(MainWindow);
        actionClient->setObjectName(QStringLiteral("actionClient"));
        actionPersonnel = new QAction(MainWindow);
        actionPersonnel->setObjectName(QStringLiteral("actionPersonnel"));
        actionA_propos = new QAction(MainWindow);
        actionA_propos->setObjectName(QStringLiteral("actionA_propos"));
        action_client_Tool = new QAction(MainWindow);
        action_client_Tool->setObjectName(QStringLiteral("action_client_Tool"));
        QIcon icon;
        icon.addFile(QStringLiteral("../ressource/clients.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_client_Tool->setIcon(icon);
        action_Personnel_Tool = new QAction(MainWindow);
        action_Personnel_Tool->setObjectName(QStringLiteral("action_Personnel_Tool"));
        QIcon icon1;
        icon1.addFile(QStringLiteral("../ressource/personnel.ico"), QSize(), QIcon::Normal, QIcon::Off);
        action_Personnel_Tool->setIcon(icon1);
        actionDivers = new QAction(MainWindow);
        actionDivers->setObjectName(QStringLiteral("actionDivers"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayout_2 = new QVBoxLayout(centralWidget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_Central = new QVBoxLayout();
        verticalLayout_Central->setSpacing(6);
        verticalLayout_Central->setObjectName(QStringLiteral("verticalLayout_Central"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tab_Client = new QWidget();
        tab_Client->setObjectName(QStringLiteral("tab_Client"));
        verticalLayout_8 = new QVBoxLayout(tab_Client);
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setContentsMargins(11, 11, 11, 11);
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout_TableView = new QVBoxLayout();
        verticalLayout_TableView->setSpacing(6);
        verticalLayout_TableView->setObjectName(QStringLiteral("verticalLayout_TableView"));
        tableViewClient = new QTableView(tab_Client);
        tableViewClient->setObjectName(QStringLiteral("tableViewClient"));
        tableViewClient->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableViewClient->setAlternatingRowColors(false);
        tableViewClient->setSelectionMode(QAbstractItemView::SingleSelection);
        tableViewClient->setSelectionBehavior(QAbstractItemView::SelectRows);

        verticalLayout_TableView->addWidget(tableViewClient);


        verticalLayout->addLayout(verticalLayout_TableView);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        verticalLayout_Recherche = new QVBoxLayout();
        verticalLayout_Recherche->setSpacing(6);
        verticalLayout_Recherche->setObjectName(QStringLiteral("verticalLayout_Recherche"));
        label_Recherche = new QLabel(tab_Client);
        label_Recherche->setObjectName(QStringLiteral("label_Recherche"));
        label_Recherche->setAlignment(Qt::AlignCenter);

        verticalLayout_Recherche->addWidget(label_Recherche);

        formLayout_Recherche = new QFormLayout();
        formLayout_Recherche->setSpacing(6);
        formLayout_Recherche->setObjectName(QStringLiteral("formLayout_Recherche"));
        label_IdRecherche = new QLabel(tab_Client);
        label_IdRecherche->setObjectName(QStringLiteral("label_IdRecherche"));
        label_IdRecherche->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout_Recherche->setWidget(0, QFormLayout::LabelRole, label_IdRecherche);

        lineEdit_IdRecherche = new QLineEdit(tab_Client);
        lineEdit_IdRecherche->setObjectName(QStringLiteral("lineEdit_IdRecherche"));

        formLayout_Recherche->setWidget(0, QFormLayout::FieldRole, lineEdit_IdRecherche);

        lab_NomRecherche = new QLabel(tab_Client);
        lab_NomRecherche->setObjectName(QStringLiteral("lab_NomRecherche"));
        lab_NomRecherche->setAlignment(Qt::AlignCenter);

        formLayout_Recherche->setWidget(1, QFormLayout::LabelRole, lab_NomRecherche);

        lineEdit_NomRecherche = new QLineEdit(tab_Client);
        lineEdit_NomRecherche->setObjectName(QStringLiteral("lineEdit_NomRecherche"));

        formLayout_Recherche->setWidget(1, QFormLayout::FieldRole, lineEdit_NomRecherche);

        lab_PrenomRecherche = new QLabel(tab_Client);
        lab_PrenomRecherche->setObjectName(QStringLiteral("lab_PrenomRecherche"));
        lab_PrenomRecherche->setAlignment(Qt::AlignCenter);

        formLayout_Recherche->setWidget(2, QFormLayout::LabelRole, lab_PrenomRecherche);

        lineEdit_PrenomRecherche = new QLineEdit(tab_Client);
        lineEdit_PrenomRecherche->setObjectName(QStringLiteral("lineEdit_PrenomRecherche"));

        formLayout_Recherche->setWidget(2, QFormLayout::FieldRole, lineEdit_PrenomRecherche);

        lab_DateMiniRecherche = new QLabel(tab_Client);
        lab_DateMiniRecherche->setObjectName(QStringLiteral("lab_DateMiniRecherche"));
        lab_DateMiniRecherche->setAlignment(Qt::AlignCenter);

        formLayout_Recherche->setWidget(3, QFormLayout::LabelRole, lab_DateMiniRecherche);

        dateEditMini = new QDateEdit(tab_Client);
        dateEditMini->setObjectName(QStringLiteral("dateEditMini"));
        dateEditMini->setMaximumDate(QDate(2099, 12, 31));
        dateEditMini->setMinimumDate(QDate(1999, 1, 1));

        formLayout_Recherche->setWidget(3, QFormLayout::FieldRole, dateEditMini);

        lab_DateMaxRecherche = new QLabel(tab_Client);
        lab_DateMaxRecherche->setObjectName(QStringLiteral("lab_DateMaxRecherche"));
        lab_DateMaxRecherche->setAlignment(Qt::AlignCenter);

        formLayout_Recherche->setWidget(4, QFormLayout::LabelRole, lab_DateMaxRecherche);

        dateEditMax = new QDateEdit(tab_Client);
        dateEditMax->setObjectName(QStringLiteral("dateEditMax"));
        dateEditMax->setMaximumDate(QDate(2099, 12, 31));
        dateEditMax->setMinimumDate(QDate(1999, 1, 1));

        formLayout_Recherche->setWidget(4, QFormLayout::FieldRole, dateEditMax);


        verticalLayout_Recherche->addLayout(formLayout_Recherche);


        horizontalLayout->addLayout(verticalLayout_Recherche);

        verticalLayout_AjoutModif = new QVBoxLayout();
        verticalLayout_AjoutModif->setSpacing(6);
        verticalLayout_AjoutModif->setObjectName(QStringLiteral("verticalLayout_AjoutModif"));
        btn_ModifierClient = new QPushButton(tab_Client);
        btn_ModifierClient->setObjectName(QStringLiteral("btn_ModifierClient"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(btn_ModifierClient->sizePolicy().hasHeightForWidth());
        btn_ModifierClient->setSizePolicy(sizePolicy);
        btn_ModifierClient->setMinimumSize(QSize(251, 61));

        verticalLayout_AjoutModif->addWidget(btn_ModifierClient);

        btn_SupprimerClient = new QPushButton(tab_Client);
        btn_SupprimerClient->setObjectName(QStringLiteral("btn_SupprimerClient"));
        sizePolicy.setHeightForWidth(btn_SupprimerClient->sizePolicy().hasHeightForWidth());
        btn_SupprimerClient->setSizePolicy(sizePolicy);
        btn_SupprimerClient->setMinimumSize(QSize(251, 61));

        verticalLayout_AjoutModif->addWidget(btn_SupprimerClient);


        horizontalLayout->addLayout(verticalLayout_AjoutModif);


        verticalLayout->addLayout(horizontalLayout);


        verticalLayout_8->addLayout(verticalLayout);

        tabWidget->addTab(tab_Client, QString());
        tab_Personnel = new QWidget();
        tab_Personnel->setObjectName(QStringLiteral("tab_Personnel"));
        verticalLayout_4 = new QVBoxLayout(tab_Personnel);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        PersView = new QTreeView(tab_Personnel);
        PersView->setObjectName(QStringLiteral("PersView"));

        verticalLayout_3->addWidget(PersView);

        button_xml = new QPushButton(tab_Personnel);
        button_xml->setObjectName(QStringLiteral("button_xml"));

        verticalLayout_3->addWidget(button_xml);

        verticalSpacer = new QSpacerItem(10, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_3->addItem(verticalSpacer);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        PersModif = new QPushButton(tab_Personnel);
        PersModif->setObjectName(QStringLiteral("PersModif"));
        PersModif->setMinimumSize(QSize(251, 61));

        horizontalLayout_2->addWidget(PersModif);

        horizontalSpacer_3 = new QSpacerItem(75, 5, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        PersSup = new QPushButton(tab_Personnel);
        PersSup->setObjectName(QStringLiteral("PersSup"));
        PersSup->setMinimumSize(QSize(251, 61));

        horizontalLayout_2->addWidget(PersSup);


        verticalLayout_3->addLayout(horizontalLayout_2);


        verticalLayout_4->addLayout(verticalLayout_3);

        tabWidget->addTab(tab_Personnel, QString());
        tab_planification = new QWidget();
        tab_planification->setObjectName(QStringLiteral("tab_planification"));
        verticalLayout_6 = new QVBoxLayout(tab_planification);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        button_Plan = new QPushButton(tab_planification);
        button_Plan->setObjectName(QStringLiteral("button_Plan"));

        horizontalLayout_3->addWidget(button_Plan);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        label = new QLabel(tab_planification);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout_5->addWidget(label);

        edit_date = new QDateEdit(tab_planification);
        edit_date->setObjectName(QStringLiteral("edit_date"));

        verticalLayout_5->addWidget(edit_date);


        horizontalLayout_3->addLayout(verticalLayout_5);


        verticalLayout_6->addLayout(horizontalLayout_3);

        tabWidget->addTab(tab_planification, QString());

        verticalLayout_Central->addWidget(tabWidget);


        verticalLayout_2->addLayout(verticalLayout_Central);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 655, 21));
        menuFichier = new QMenu(menuBar);
        menuFichier->setObjectName(QStringLiteral("menuFichier"));
        menuAjouter = new QMenu(menuFichier);
        menuAjouter->setObjectName(QStringLiteral("menuAjouter"));
        menu = new QMenu(menuBar);
        menu->setObjectName(QStringLiteral("menu"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuFichier->menuAction());
        menuBar->addAction(menu->menuAction());
        menuFichier->addAction(menuAjouter->menuAction());
        menuFichier->addSeparator();
        menuFichier->addAction(actionQuitter);
        menuFichier->addSeparator();
        menuAjouter->addAction(actionClient);
        menuAjouter->addAction(actionPersonnel);
        menuAjouter->addAction(actionDivers);
        menu->addAction(actionA_propos);
        mainToolBar->addAction(action_client_Tool);
        mainToolBar->addAction(action_Personnel_Tool);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Accueil", nullptr));
        actionQuitter->setText(QApplication::translate("MainWindow", "Quitter", nullptr));
        actionClient->setText(QApplication::translate("MainWindow", "Client", nullptr));
        actionPersonnel->setText(QApplication::translate("MainWindow", "Personnel", nullptr));
        actionA_propos->setText(QApplication::translate("MainWindow", "A propos", nullptr));
        action_client_Tool->setText(QApplication::translate("MainWindow", "Client", nullptr));
#ifndef QT_NO_TOOLTIP
        action_client_Tool->setToolTip(QApplication::translate("MainWindow", "Ajouter un client", nullptr));
#endif // QT_NO_TOOLTIP
        action_Personnel_Tool->setText(QApplication::translate("MainWindow", "Personnel", nullptr));
#ifndef QT_NO_TOOLTIP
        action_Personnel_Tool->setToolTip(QApplication::translate("MainWindow", "Ajouter un personnel", nullptr));
#endif // QT_NO_TOOLTIP
        actionDivers->setText(QApplication::translate("MainWindow", "Divers", nullptr));
        label_Recherche->setText(QApplication::translate("MainWindow", "Recherche :", nullptr));
        label_IdRecherche->setText(QApplication::translate("MainWindow", "Id :", nullptr));
        lab_NomRecherche->setText(QApplication::translate("MainWindow", "Nom :", nullptr));
        lab_PrenomRecherche->setText(QApplication::translate("MainWindow", "Pr\303\251nom :", nullptr));
        lab_DateMiniRecherche->setText(QApplication::translate("MainWindow", "De :", nullptr));
        dateEditMini->setDisplayFormat(QApplication::translate("MainWindow", "yyyy-MM-dd", nullptr));
        lab_DateMaxRecherche->setText(QApplication::translate("MainWindow", "A :", nullptr));
        dateEditMax->setDisplayFormat(QApplication::translate("MainWindow", "yyyy-MM-dd", nullptr));
        btn_ModifierClient->setText(QApplication::translate("MainWindow", "Modifier", nullptr));
        btn_SupprimerClient->setText(QApplication::translate("MainWindow", "Supprimer", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_Client), QApplication::translate("MainWindow", "Client", nullptr));
        button_xml->setText(QApplication::translate("MainWindow", "Generer XML", nullptr));
        PersModif->setText(QApplication::translate("MainWindow", "Modifier", nullptr));
        PersSup->setText(QApplication::translate("MainWindow", "Supprimer", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_Personnel), QApplication::translate("MainWindow", "Personnel", nullptr));
        button_Plan->setText(QApplication::translate("MainWindow", "Planifier", nullptr));
        label->setText(QApplication::translate("MainWindow", "Veuillez saisir une date:", nullptr));
        edit_date->setDisplayFormat(QApplication::translate("MainWindow", "yyyy-mm-dd", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_planification), QApplication::translate("MainWindow", "Planification", nullptr));
        menuFichier->setTitle(QApplication::translate("MainWindow", "Fichier", nullptr));
        menuAjouter->setTitle(QApplication::translate("MainWindow", "Ajouter", nullptr));
        menu->setTitle(QApplication::translate("MainWindow", "?", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
