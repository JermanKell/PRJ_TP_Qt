/********************************************************************************
** Form generated from reading UI file 'aproposwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APROPOSWINDOW_H
#define UI_APROPOSWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_AProposWindow
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label_polytech;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_createurs;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_version;

    void setupUi(QDialog *AProposWindow)
    {
        if (AProposWindow->objectName().isEmpty())
            AProposWindow->setObjectName(QStringLiteral("AProposWindow"));
        AProposWindow->resize(320, 148);
        gridLayout = new QGridLayout(AProposWindow);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetFixedSize);
        verticalLayout->setContentsMargins(0, 0, 0, -1);
        label_polytech = new QLabel(AProposWindow);
        label_polytech->setObjectName(QStringLiteral("label_polytech"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_polytech->sizePolicy().hasHeightForWidth());
        label_polytech->setSizePolicy(sizePolicy);
        label_polytech->setMaximumSize(QSize(150, 85));
        label_polytech->setTextFormat(Qt::AutoText);
        label_polytech->setPixmap(QPixmap(QString::fromUtf8("../ressource/Logo_Reseau_Polytech.png")));
        label_polytech->setScaledContents(true);

        verticalLayout->addWidget(label_polytech);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(10, 10, 10, 10);
        label_createurs = new QLabel(AProposWindow);
        label_createurs->setObjectName(QStringLiteral("label_createurs"));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        label_createurs->setFont(font);
        label_createurs->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_createurs);


        gridLayout->addLayout(verticalLayout_2, 1, 0, 1, 2);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        label_version = new QLabel(AProposWindow);
        label_version->setObjectName(QStringLiteral("label_version"));
        label_version->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label_version);


        gridLayout->addLayout(verticalLayout_3, 0, 1, 1, 1);


        retranslateUi(AProposWindow);

        QMetaObject::connectSlotsByName(AProposWindow);
    } // setupUi

    void retranslateUi(QDialog *AProposWindow)
    {
        AProposWindow->setWindowTitle(QApplication::translate("AProposWindow", "A propos", nullptr));
        label_polytech->setText(QString());
        label_createurs->setText(QApplication::translate("AProposWindow", "Bouchenard Xavier & Lazzaroni Rapha\303\253l", nullptr));
        label_version->setText(QApplication::translate("AProposWindow", "version 0.1", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AProposWindow: public Ui_AProposWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APROPOSWINDOW_H
