/********************************************************************************
** Form generated from reading UI file 'ajouterclientwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AJOUTERCLIENTWINDOW_H
#define UI_AJOUTERCLIENTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_AjouterClientWindow
{
public:
    QVBoxLayout *verticalLayout;
    QFormLayout *formLayout;
    QLabel *lab_Nom;
    QLineEdit *lineEdit_Nom;
    QLabel *label_Prenom;
    QLineEdit *lineEdit_Prenom;
    QLabel *label_Adresse;
    QLineEdit *lineEdit_Adresse;
    QLabel *label_Ville;
    QLineEdit *lineEdit_Ville;
    QLabel *label_CodePostal;
    QLineEdit *lineEdit_CodePostal;
    QLabel *label_DateRDV;
    QDateEdit *dateEdit_dateRDV;
    QLabel *label_Duree;
    QLineEdit *lineEdit_Duree;
    QLabel *label_Priorite;
    QLineEdit *lineEdit_Priorite;
    QLabel *label_Ressources;
    QListWidget *listWidget_Ressources;
    QLabel *label_Commentaires;
    QTextEdit *textEdit_Commentaires;
    QLabel *label_Telephone;
    QLineEdit *lineEdit_Telephone;
    QLineEdit *lineEdit_Remarque;
    QLabel *label_Remarque;
    QDialogButtonBox *QDialog_btn_ValiderAjoutClient;

    void setupUi(QDialog *AjouterClientWindow)
    {
        if (AjouterClientWindow->objectName().isEmpty())
            AjouterClientWindow->setObjectName(QStringLiteral("AjouterClientWindow"));
        AjouterClientWindow->resize(378, 673);
        verticalLayout = new QVBoxLayout(AjouterClientWindow);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        formLayout = new QFormLayout();
        formLayout->setObjectName(QStringLiteral("formLayout"));
        formLayout->setLabelAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lab_Nom = new QLabel(AjouterClientWindow);
        lab_Nom->setObjectName(QStringLiteral("lab_Nom"));
        lab_Nom->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(0, QFormLayout::LabelRole, lab_Nom);

        lineEdit_Nom = new QLineEdit(AjouterClientWindow);
        lineEdit_Nom->setObjectName(QStringLiteral("lineEdit_Nom"));

        formLayout->setWidget(0, QFormLayout::FieldRole, lineEdit_Nom);

        label_Prenom = new QLabel(AjouterClientWindow);
        label_Prenom->setObjectName(QStringLiteral("label_Prenom"));
        label_Prenom->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(1, QFormLayout::LabelRole, label_Prenom);

        lineEdit_Prenom = new QLineEdit(AjouterClientWindow);
        lineEdit_Prenom->setObjectName(QStringLiteral("lineEdit_Prenom"));

        formLayout->setWidget(1, QFormLayout::FieldRole, lineEdit_Prenom);

        label_Adresse = new QLabel(AjouterClientWindow);
        label_Adresse->setObjectName(QStringLiteral("label_Adresse"));
        label_Adresse->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(2, QFormLayout::LabelRole, label_Adresse);

        lineEdit_Adresse = new QLineEdit(AjouterClientWindow);
        lineEdit_Adresse->setObjectName(QStringLiteral("lineEdit_Adresse"));

        formLayout->setWidget(2, QFormLayout::FieldRole, lineEdit_Adresse);

        label_Ville = new QLabel(AjouterClientWindow);
        label_Ville->setObjectName(QStringLiteral("label_Ville"));
        label_Ville->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(3, QFormLayout::LabelRole, label_Ville);

        lineEdit_Ville = new QLineEdit(AjouterClientWindow);
        lineEdit_Ville->setObjectName(QStringLiteral("lineEdit_Ville"));

        formLayout->setWidget(3, QFormLayout::FieldRole, lineEdit_Ville);

        label_CodePostal = new QLabel(AjouterClientWindow);
        label_CodePostal->setObjectName(QStringLiteral("label_CodePostal"));
        label_CodePostal->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(4, QFormLayout::LabelRole, label_CodePostal);

        lineEdit_CodePostal = new QLineEdit(AjouterClientWindow);
        lineEdit_CodePostal->setObjectName(QStringLiteral("lineEdit_CodePostal"));
        lineEdit_CodePostal->setMaxLength(5);

        formLayout->setWidget(4, QFormLayout::FieldRole, lineEdit_CodePostal);

        label_DateRDV = new QLabel(AjouterClientWindow);
        label_DateRDV->setObjectName(QStringLiteral("label_DateRDV"));
        label_DateRDV->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(5, QFormLayout::LabelRole, label_DateRDV);

        dateEdit_dateRDV = new QDateEdit(AjouterClientWindow);
        dateEdit_dateRDV->setObjectName(QStringLiteral("dateEdit_dateRDV"));
        dateEdit_dateRDV->setDateTime(QDateTime(QDate(2018, 3, 15), QTime(0, 0, 0)));
        dateEdit_dateRDV->setMaximumDateTime(QDateTime(QDate(2099, 12, 31), QTime(23, 59, 59)));
        dateEdit_dateRDV->setMinimumDateTime(QDateTime(QDate(2018, 3, 15), QTime(0, 0, 0)));
        dateEdit_dateRDV->setCurrentSectionIndex(0);

        formLayout->setWidget(5, QFormLayout::FieldRole, dateEdit_dateRDV);

        label_Duree = new QLabel(AjouterClientWindow);
        label_Duree->setObjectName(QStringLiteral("label_Duree"));
        label_Duree->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(6, QFormLayout::LabelRole, label_Duree);

        lineEdit_Duree = new QLineEdit(AjouterClientWindow);
        lineEdit_Duree->setObjectName(QStringLiteral("lineEdit_Duree"));
        lineEdit_Duree->setInputMethodHints(Qt::ImhNone);
        lineEdit_Duree->setCursorPosition(2);
        lineEdit_Duree->setClearButtonEnabled(false);

        formLayout->setWidget(6, QFormLayout::FieldRole, lineEdit_Duree);

        label_Priorite = new QLabel(AjouterClientWindow);
        label_Priorite->setObjectName(QStringLiteral("label_Priorite"));
        label_Priorite->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(7, QFormLayout::LabelRole, label_Priorite);

        lineEdit_Priorite = new QLineEdit(AjouterClientWindow);
        lineEdit_Priorite->setObjectName(QStringLiteral("lineEdit_Priorite"));

        formLayout->setWidget(7, QFormLayout::FieldRole, lineEdit_Priorite);

        label_Ressources = new QLabel(AjouterClientWindow);
        label_Ressources->setObjectName(QStringLiteral("label_Ressources"));
        label_Ressources->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(8, QFormLayout::LabelRole, label_Ressources);

        listWidget_Ressources = new QListWidget(AjouterClientWindow);
        listWidget_Ressources->setObjectName(QStringLiteral("listWidget_Ressources"));
        listWidget_Ressources->setSelectionMode(QAbstractItemView::MultiSelection);
        listWidget_Ressources->setSelectionBehavior(QAbstractItemView::SelectItems);

        formLayout->setWidget(8, QFormLayout::FieldRole, listWidget_Ressources);

        label_Commentaires = new QLabel(AjouterClientWindow);
        label_Commentaires->setObjectName(QStringLiteral("label_Commentaires"));
        label_Commentaires->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(9, QFormLayout::LabelRole, label_Commentaires);

        textEdit_Commentaires = new QTextEdit(AjouterClientWindow);
        textEdit_Commentaires->setObjectName(QStringLiteral("textEdit_Commentaires"));

        formLayout->setWidget(9, QFormLayout::FieldRole, textEdit_Commentaires);

        label_Telephone = new QLabel(AjouterClientWindow);
        label_Telephone->setObjectName(QStringLiteral("label_Telephone"));
        label_Telephone->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(10, QFormLayout::LabelRole, label_Telephone);

        lineEdit_Telephone = new QLineEdit(AjouterClientWindow);
        lineEdit_Telephone->setObjectName(QStringLiteral("lineEdit_Telephone"));
        lineEdit_Telephone->setMaxLength(9);

        formLayout->setWidget(10, QFormLayout::FieldRole, lineEdit_Telephone);

        lineEdit_Remarque = new QLineEdit(AjouterClientWindow);
        lineEdit_Remarque->setObjectName(QStringLiteral("lineEdit_Remarque"));

        formLayout->setWidget(11, QFormLayout::FieldRole, lineEdit_Remarque);

        label_Remarque = new QLabel(AjouterClientWindow);
        label_Remarque->setObjectName(QStringLiteral("label_Remarque"));

        formLayout->setWidget(11, QFormLayout::LabelRole, label_Remarque);


        verticalLayout->addLayout(formLayout);

        QDialog_btn_ValiderAjoutClient = new QDialogButtonBox(AjouterClientWindow);
        QDialog_btn_ValiderAjoutClient->setObjectName(QStringLiteral("QDialog_btn_ValiderAjoutClient"));
        QDialog_btn_ValiderAjoutClient->setOrientation(Qt::Horizontal);
        QDialog_btn_ValiderAjoutClient->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(QDialog_btn_ValiderAjoutClient);


        retranslateUi(AjouterClientWindow);
        QObject::connect(QDialog_btn_ValiderAjoutClient, SIGNAL(accepted()), AjouterClientWindow, SLOT(accept()));
        QObject::connect(QDialog_btn_ValiderAjoutClient, SIGNAL(rejected()), AjouterClientWindow, SLOT(reject()));

        QMetaObject::connectSlotsByName(AjouterClientWindow);
    } // setupUi

    void retranslateUi(QDialog *AjouterClientWindow)
    {
        AjouterClientWindow->setWindowTitle(QApplication::translate("AjouterClientWindow", "Ajouter un client", nullptr));
        lab_Nom->setText(QApplication::translate("AjouterClientWindow", "Nom : ", nullptr));
        label_Prenom->setText(QApplication::translate("AjouterClientWindow", "Prenom : ", nullptr));
        label_Adresse->setText(QApplication::translate("AjouterClientWindow", "Adresse : ", nullptr));
        label_Ville->setText(QApplication::translate("AjouterClientWindow", "Ville : ", nullptr));
        label_CodePostal->setText(QApplication::translate("AjouterClientWindow", "Code postal : ", nullptr));
        label_DateRDV->setText(QApplication::translate("AjouterClientWindow", "Date rendez-vous : ", nullptr));
        dateEdit_dateRDV->setDisplayFormat(QApplication::translate("AjouterClientWindow", "yyyy-MM-dd", nullptr));
        label_Duree->setText(QApplication::translate("AjouterClientWindow", "Duree (minutes) : ", nullptr));
        lineEdit_Duree->setText(QApplication::translate("AjouterClientWindow", "60", nullptr));
        label_Priorite->setText(QApplication::translate("AjouterClientWindow", "Priorite : ", nullptr));
        lineEdit_Priorite->setText(QApplication::translate("AjouterClientWindow", "1", nullptr));
        label_Ressources->setText(QApplication::translate("AjouterClientWindow", "Ressources : ", nullptr));
        label_Commentaires->setText(QApplication::translate("AjouterClientWindow", "Commentaires : ", nullptr));
        label_Telephone->setText(QApplication::translate("AjouterClientWindow", "Telephone : ", nullptr));
        label_Remarque->setText(QApplication::translate("AjouterClientWindow", "Remarque : ", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AjouterClientWindow: public Ui_AjouterClientWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AJOUTERCLIENTWINDOW_H
