/********************************************************************************
** Form generated from reading UI file 'ajouterpersonnelwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AJOUTERPERSONNELWINDOW_H
#define UI_AJOUTERPERSONNELWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_AjouterPersonnelWindow
{
public:
    QVBoxLayout *verticalLayout;
    QVBoxLayout *verticalLayout_2;
    QLabel *lab_Nom;
    QLineEdit *edit_Nom;
    QLabel *lab_Prenom;
    QLineEdit *edit_Prenom;
    QLabel *lab_Sit;
    QComboBox *edit_Sit;
    QLabel *lab_Id;
    QLineEdit *edit_Id;
    QLabel *lab_MdP;
    QLineEdit *edit_MdP;
    QDialogButtonBox *QDialog_btn_ValiderAjoutPersonnel;

    void setupUi(QDialog *AjouterPersonnelWindow)
    {
        if (AjouterPersonnelWindow->objectName().isEmpty())
            AjouterPersonnelWindow->setObjectName(QStringLiteral("AjouterPersonnelWindow"));
        AjouterPersonnelWindow->resize(450, 300);
        AjouterPersonnelWindow->setLayoutDirection(Qt::LeftToRight);
        verticalLayout = new QVBoxLayout(AjouterPersonnelWindow);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        lab_Nom = new QLabel(AjouterPersonnelWindow);
        lab_Nom->setObjectName(QStringLiteral("lab_Nom"));

        verticalLayout_2->addWidget(lab_Nom);

        edit_Nom = new QLineEdit(AjouterPersonnelWindow);
        edit_Nom->setObjectName(QStringLiteral("edit_Nom"));

        verticalLayout_2->addWidget(edit_Nom);

        lab_Prenom = new QLabel(AjouterPersonnelWindow);
        lab_Prenom->setObjectName(QStringLiteral("lab_Prenom"));

        verticalLayout_2->addWidget(lab_Prenom);

        edit_Prenom = new QLineEdit(AjouterPersonnelWindow);
        edit_Prenom->setObjectName(QStringLiteral("edit_Prenom"));

        verticalLayout_2->addWidget(edit_Prenom);

        lab_Sit = new QLabel(AjouterPersonnelWindow);
        lab_Sit->setObjectName(QStringLiteral("lab_Sit"));

        verticalLayout_2->addWidget(lab_Sit);

        edit_Sit = new QComboBox(AjouterPersonnelWindow);
        edit_Sit->setObjectName(QStringLiteral("edit_Sit"));

        verticalLayout_2->addWidget(edit_Sit);

        lab_Id = new QLabel(AjouterPersonnelWindow);
        lab_Id->setObjectName(QStringLiteral("lab_Id"));

        verticalLayout_2->addWidget(lab_Id);

        edit_Id = new QLineEdit(AjouterPersonnelWindow);
        edit_Id->setObjectName(QStringLiteral("edit_Id"));

        verticalLayout_2->addWidget(edit_Id);

        lab_MdP = new QLabel(AjouterPersonnelWindow);
        lab_MdP->setObjectName(QStringLiteral("lab_MdP"));

        verticalLayout_2->addWidget(lab_MdP);

        edit_MdP = new QLineEdit(AjouterPersonnelWindow);
        edit_MdP->setObjectName(QStringLiteral("edit_MdP"));

        verticalLayout_2->addWidget(edit_MdP);

        QDialog_btn_ValiderAjoutPersonnel = new QDialogButtonBox(AjouterPersonnelWindow);
        QDialog_btn_ValiderAjoutPersonnel->setObjectName(QStringLiteral("QDialog_btn_ValiderAjoutPersonnel"));
        QDialog_btn_ValiderAjoutPersonnel->setOrientation(Qt::Horizontal);
        QDialog_btn_ValiderAjoutPersonnel->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout_2->addWidget(QDialog_btn_ValiderAjoutPersonnel);


        verticalLayout->addLayout(verticalLayout_2);


        retranslateUi(AjouterPersonnelWindow);
        QObject::connect(QDialog_btn_ValiderAjoutPersonnel, SIGNAL(accepted()), AjouterPersonnelWindow, SLOT(accept()));
        QObject::connect(QDialog_btn_ValiderAjoutPersonnel, SIGNAL(rejected()), AjouterPersonnelWindow, SLOT(reject()));

        QMetaObject::connectSlotsByName(AjouterPersonnelWindow);
    } // setupUi

    void retranslateUi(QDialog *AjouterPersonnelWindow)
    {
        AjouterPersonnelWindow->setWindowTitle(QApplication::translate("AjouterPersonnelWindow", "Ajouter un personnel", nullptr));
        lab_Nom->setText(QApplication::translate("AjouterPersonnelWindow", "Veuillez saisir votre nom :", nullptr));
        edit_Nom->setText(QString());
        lab_Prenom->setText(QApplication::translate("AjouterPersonnelWindow", "Veuillez saisir votre pr\303\251nom :", nullptr));
        lab_Sit->setText(QApplication::translate("AjouterPersonnelWindow", "Quel est votre situation professionnelle ?", nullptr));
        lab_Id->setText(QApplication::translate("AjouterPersonnelWindow", "Id ?", nullptr));
        lab_MdP->setText(QApplication::translate("AjouterPersonnelWindow", "MdP ?", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AjouterPersonnelWindow: public Ui_AjouterPersonnelWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AJOUTERPERSONNELWINDOW_H
