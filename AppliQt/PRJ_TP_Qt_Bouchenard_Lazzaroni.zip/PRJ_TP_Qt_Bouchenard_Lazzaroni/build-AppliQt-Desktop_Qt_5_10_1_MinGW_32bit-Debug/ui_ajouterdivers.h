/********************************************************************************
** Form generated from reading UI file 'ajouterdivers.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AJOUTERDIVERS_H
#define UI_AJOUTERDIVERS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ajouterDivers
{
public:
    QDialogButtonBox *buttonBox;
    QWidget *widget;
    QFormLayout *formLayout;
    QLabel *lab_Nom;
    QLabel *lab_Prenom;
    QLineEdit *edit_nom;
    QLineEdit *edit_prenom;

    void setupUi(QDialog *ajouterDivers)
    {
        if (ajouterDivers->objectName().isEmpty())
            ajouterDivers->setObjectName(QStringLiteral("ajouterDivers"));
        ajouterDivers->resize(400, 300);
        buttonBox = new QDialogButtonBox(ajouterDivers);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(30, 240, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        widget = new QWidget(ajouterDivers);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(20, 70, 371, 151));
        formLayout = new QFormLayout(widget);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        lab_Nom = new QLabel(widget);
        lab_Nom->setObjectName(QStringLiteral("lab_Nom"));

        formLayout->setWidget(0, QFormLayout::LabelRole, lab_Nom);

        lab_Prenom = new QLabel(widget);
        lab_Prenom->setObjectName(QStringLiteral("lab_Prenom"));

        formLayout->setWidget(2, QFormLayout::LabelRole, lab_Prenom);

        edit_nom = new QLineEdit(widget);
        edit_nom->setObjectName(QStringLiteral("edit_nom"));

        formLayout->setWidget(0, QFormLayout::FieldRole, edit_nom);

        edit_prenom = new QLineEdit(widget);
        edit_prenom->setObjectName(QStringLiteral("edit_prenom"));

        formLayout->setWidget(2, QFormLayout::FieldRole, edit_prenom);


        retranslateUi(ajouterDivers);
        QObject::connect(buttonBox, SIGNAL(accepted()), ajouterDivers, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), ajouterDivers, SLOT(reject()));

        QMetaObject::connectSlotsByName(ajouterDivers);
    } // setupUi

    void retranslateUi(QDialog *ajouterDivers)
    {
        ajouterDivers->setWindowTitle(QApplication::translate("ajouterDivers", "Dialog", nullptr));
        lab_Nom->setText(QApplication::translate("ajouterDivers", "Saisir le nom:", nullptr));
        lab_Prenom->setText(QApplication::translate("ajouterDivers", "Saisir le prenom:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ajouterDivers: public Ui_ajouterDivers {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AJOUTERDIVERS_H
