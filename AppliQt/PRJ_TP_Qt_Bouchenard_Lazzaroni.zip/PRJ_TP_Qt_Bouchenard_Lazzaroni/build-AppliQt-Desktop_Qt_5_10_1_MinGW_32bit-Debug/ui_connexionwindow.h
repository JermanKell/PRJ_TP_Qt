/********************************************************************************
** Form generated from reading UI file 'connexionwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONNEXIONWINDOW_H
#define UI_CONNEXIONWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ConnexionWindow
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_connexion;
    QPushButton *pushButton_annuler;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QLabel *label_mdp;
    QLabel *label_id;
    QLineEdit *lineEdit_Id;
    QLineEdit *lineEdit_Mdp;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label_Title;

    void setupUi(QDialog *ConnexionWindow)
    {
        if (ConnexionWindow->objectName().isEmpty())
            ConnexionWindow->setObjectName(QStringLiteral("ConnexionWindow"));
        ConnexionWindow->resize(316, 264);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(ConnexionWindow->sizePolicy().hasHeightForWidth());
        ConnexionWindow->setSizePolicy(sizePolicy);
        ConnexionWindow->setMinimumSize(QSize(316, 264));
        ConnexionWindow->setMaximumSize(QSize(316, 264));
        horizontalLayoutWidget = new QWidget(ConnexionWindow);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(10, 220, 291, 31));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_connexion = new QPushButton(horizontalLayoutWidget);
        pushButton_connexion->setObjectName(QStringLiteral("pushButton_connexion"));

        horizontalLayout->addWidget(pushButton_connexion);

        pushButton_annuler = new QPushButton(horizontalLayoutWidget);
        pushButton_annuler->setObjectName(QStringLiteral("pushButton_annuler"));

        horizontalLayout->addWidget(pushButton_annuler);

        gridLayoutWidget = new QWidget(ConnexionWindow);
        gridLayoutWidget->setObjectName(QStringLiteral("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(10, 70, 291, 151));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label_mdp = new QLabel(gridLayoutWidget);
        label_mdp->setObjectName(QStringLiteral("label_mdp"));
        label_mdp->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_mdp, 1, 0, 1, 1);

        label_id = new QLabel(gridLayoutWidget);
        label_id->setObjectName(QStringLiteral("label_id"));
        label_id->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_id, 0, 0, 1, 1);

        lineEdit_Id = new QLineEdit(gridLayoutWidget);
        lineEdit_Id->setObjectName(QStringLiteral("lineEdit_Id"));

        gridLayout->addWidget(lineEdit_Id, 0, 1, 1, 1);

        lineEdit_Mdp = new QLineEdit(gridLayoutWidget);
        lineEdit_Mdp->setObjectName(QStringLiteral("lineEdit_Mdp"));

        gridLayout->addWidget(lineEdit_Mdp, 1, 1, 1, 1);

        verticalLayoutWidget = new QWidget(ConnexionWindow);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(10, 10, 291, 61));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_Title = new QLabel(verticalLayoutWidget);
        label_Title->setObjectName(QStringLiteral("label_Title"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label_Title->sizePolicy().hasHeightForWidth());
        label_Title->setSizePolicy(sizePolicy1);
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        label_Title->setFont(font);
        label_Title->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_Title);


        retranslateUi(ConnexionWindow);

        QMetaObject::connectSlotsByName(ConnexionWindow);
    } // setupUi

    void retranslateUi(QDialog *ConnexionWindow)
    {
        ConnexionWindow->setWindowTitle(QApplication::translate("ConnexionWindow", "Dialog", nullptr));
        pushButton_connexion->setText(QApplication::translate("ConnexionWindow", "Connexion", nullptr));
        pushButton_annuler->setText(QApplication::translate("ConnexionWindow", "Annuler", nullptr));
        label_mdp->setText(QApplication::translate("ConnexionWindow", "Mot de passe : ", nullptr));
        label_id->setText(QApplication::translate("ConnexionWindow", "Identifiant : ", nullptr));
        label_Title->setText(QApplication::translate("ConnexionWindow", "Authentification", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ConnexionWindow: public Ui_ConnexionWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONNEXIONWINDOW_H
