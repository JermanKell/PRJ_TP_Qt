#ifndef C_INIT_BD_H
#define C_INIT_BD_H


class C_INIT_BD
{
    private:
        C_INIT_BD();
    public:
        static bool Creation_BD(void);
};

#endif // C_INIT_BD_H
